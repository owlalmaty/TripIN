import { Component, OnInit, ViewChild } from '@angular/core';
import { AirportService } from '../../services/airport.service';
import { Observable } from 'rxjs/Observable';
import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component({
  selector: 'app-home-airports',
  templateUrl: './home-airports.component.html',
  styleUrls: ['./home-airports.component.scss']
})
export class HomeAirportsComponent implements OnInit {
  
  constructor(private airportService: AirportService) { }

  airports: any[];
  ngOnInit() {
    this.getAirports();
  }
  getAirports(): any {
    this.airportService.getAll<any[]>()
    .subscribe((data: any[]) => this.airports = data["value"]);
  }
}

