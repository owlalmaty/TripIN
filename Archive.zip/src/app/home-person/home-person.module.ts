import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomePersonComponent } from './home-person.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [HomePersonComponent]
})
export class HomePersonModule { }
